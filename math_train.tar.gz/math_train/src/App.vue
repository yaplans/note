<template>
<div class="traning">
<h1>Math traning</h1>
<hr>
<!--если v-if=true отобразится-->
<!--если @onStart зарегистрирован с помощью emit -->
<app-start-screen v-if="state==='start'"
	@onStart="do_onStart"
></app-start-screen>
<AppMessage v-if="state==='message'"
	@onMessage="do_onMessage"
></AppMessage>
<AppQuestion v-if="state==='question'"
	@onQuestion="do_onQuestion"
></AppQuestion>
<AppResultScreen v-if="state==='result'"
	@onResult="do_onResult"
></AppResultScreen>

</div>

<!--
  <div id="app">
    <img src="./assets/logo.png">
    <h1>{{ msg }}</h1>
    <h2>Essential Links</h2>
    <ul>
      <li><a href="https://vuejs.org" target="_blank">Core Docs</a></li>
      <li><a href="https://forum.vuejs.org" target="_blank">Forum</a></li>
      <li><a href="https://chat.vuejs.org" target="_blank">Community Chat</a></li>
      <li><a href="https://twitter.com/vuejs" target="_blank">Twitter</a></li>
    </ul>
    <h2>Ecosystem</h2>
    <ul>
      <li><a href="http://router.vuejs.org/" target="_blank">vue-router</a></li>
      <li><a href="http://vuex.vuejs.org/" target="_blank">vuex</a></li>
      <li><a href="http://vue-loader.vuejs.org/" target="_blank">vue-loader</a></li>
      <li><a href="https://github.com/vuejs/awesome-vue" target="_blank">awesome-vue</a></li>
    </ul>
  </div>
  -->
</template>

<script>
export default {
  name: 'app',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App',
      state: "start"
    }
  },
  methods: {
	do_onStart() {
		//alert("do_onStart");
		this.state="question";
	},
	do_onQuestion() {
		//alert("do_onStart");
		this.state="message";
	},
	do_onMessage() {
		this.state="question";
	}
  }
}
</script>

<style scoped>

.traning {
	max-width: 700px;
	margin: 20px auto;
}

#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>
