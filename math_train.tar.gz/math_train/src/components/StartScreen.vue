<template>
<div class="m_frame alert alert-info">

<h3>StartScreen</h3>
<!--
<button class="btn btn-success" v-on:click="but_click">Start</button>
-->
<button class="btn btn-success" v-on:click='$emit("onStart")'>Start</button>

</div>


</template>

<script>
	export default{
	/*
	methods: {
		but_click(){
			console.log(this);
			alert("Start");
		}
	}
	*/
	}
</script>

<style scoped>
.m_frame {
	/*height: 200px;*/
}
.alert {
	text-align: center;
}
h3, .btn {
	margin: 30px 0;

}
</style>
