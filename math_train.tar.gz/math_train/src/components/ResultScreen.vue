<template>
<div class="m_frame alert alert-success">ResultScreen</div>
</template>

<script scoped>
	export default{
	}
</script>

<style>
.m_frame {
height: 200px;
/*

background: green;
*/
}
</style>
