<template>
<div class="m_frame alert alert-secondary">

<div>
{{ x }} + {{ y }} = ?
</div>

	<button class="btn btn-success" 
		v-on:click='$emit("onQuestion")'
	>Question</button>

</div>
</template>

<script>
	export default{
		data(){
			return {
			x: 1,
			y: 1
			}
		}
	}
</script>

<style scoped>
.m_frame {
	height: 200px;
}
</style>
