<template>

<div class="m_frame alert alert-warning">

	<button class="btn btn-success" 
		v-on:click='$emit("onMessage")'
	>Message</button>

</div>
</template>

<script scoped>
	export default{
	}
</script>

<style>
.m_frame {
	height: 200px;
}
</style>
